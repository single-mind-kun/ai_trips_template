---
name: travel-guide-planner
description: Collect traveler requirements before researching, planning, and producing a verifiable travel guide with daily schedules, door-to-door transport, attractions and tickets, food, lodging, budget, contingencies, packing, and optional travel-journal visuals. Use when a user asks to create, plan, refine, or turn trip materials into a multi-part itinerary or travel guide. Do not use for a single isolated lookup such as one train, one hotel, current weather, or a factual destination question.
---

# Travel Guide Planner

Build a trip only after the traveler’s requirements and fixed bookings are clear enough to avoid planning the wrong journey.

## Intake gate

On the first planning request:

1. Extract every fact already supplied. Do not ask for information the user has already given.
2. If essential information is missing, give the user [assets/travel-planning-intake.md](assets/travel-planning-intake.md) to fill in and upload, or paste only its relevant questions into chat.
3. Ask the user to write “不确定” for unknown items. Do not force false precision.
4. Do not begin broad research, produce a final route, or generate visuals until the completed intake is returned, unless the user explicitly requests a rough idea only.
5. If the user has already supplied enough information, show a short normalized summary and ask only one concise batch of remaining questions. Do not require them to refill the form.

Essential information for a full guide:

- origin, return point, exact or approximate dates, number and type of travelers;
- must-see places, optional places, interests, pace, walking tolerance, earliest start, latest finish;
- budget basis and whether it includes long-distance transport;
- preferred transport, lodging, room arrangement, food preferences and restrictions;
- fixed or pending tickets, reservations, hotels, appointments, and cancellation deadlines;
- baggage, accessibility, health, child, elder, visa, driving, or other constraints;
- desired deliverables, such as Markdown guide, booking checklist, maps, packing list, or travel-journal images.

Dates, fixed bookings, must-do items, accessibility needs, and the return deadline are blocking fields. Minor preferences may remain unknown and become explicit assumptions.

## After the intake is returned

1. Parse uploaded forms, screenshots, tickets, confirmations, prior itineraries, and links.
2. Produce a compact “confirmed / pending / assumed / conflicting” summary.
3. Check date order, number of nights, traveler count, station and airport names, room occupancy, ticket times, check-in rules, and cancellation deadlines.
4. If a conflict could invalidate the route, stop and ask one focused question. Otherwise state the assumption and continue.
5. Ask the user to confirm the route skeleton before spending substantial effort on detailed lodging, dining, or visual production when several materially different routes remain possible.

## Choose the delivery depth

- **Quick:** route skeleton, daily highlights, major transport, rough budget, and critical bookings.
- **Standard:** complete daily itinerary, transport, attractions and tickets, food, lodging, budget, tips, packing, sources, and Plan B.
- **Execution:** Standard plus internal attraction routes, door-to-door transfers, luggage handoffs, booking/cancellation checkpoints, decision thresholds, contact cards, and visual-production prompts.

Use Standard when the user does not choose. Upgrade risky days to Execution depth for holidays, tight transfers, several cities, large groups, children, elders, or accessibility needs.

## Research and verification

Current schedules, prices, availability, operating rules, laws, weather, events, and recommendations are unstable. Verify them with current sources when the environment provides internet or specialist tools.

Source priority:

1. government, tourism bureau, attraction, transport operator, rail, airline, and lodging official sources;
2. date-specific booking pages and reliable map/navigation data;
3. recent platform reviews and social posts for experience and pitfalls, never as the sole authority for rules.

Record the lookup date. Keep these labels visible:

- ✅ verified by an official or live source;
- ⚠️ pending verification or based on a secondary source;
- 💡 planning judgment rather than an official fact;
- 🔁 contingency.

Do not invent schedules, prices, addresses, availability, opening hours, booking rules, discounts, or contact details. Preserve words such as “approximately”, “estimated”, and “reference price”. Explain meaningful source conflicts.

## Build the itinerary

Read [references/guide-structure.md](references/guide-structure.md) after intake when producing a Standard or Execution guide.

Plan in this order:

1. Place fixed bookings, closing days, reservation windows, last departures, and return deadline.
2. Identify the hard conditions that make the trip feasible.
3. Cluster places geographically and prefer one-way movement between cities.
4. Estimate door-to-door time, including baggage, walking, security, queues, transfers, meals, and rest.
5. Keep 10–20% usable buffer and reduce arrival/departure days.
6. Select lodging areas from the route rather than forcing the route around a fashionable hotel.
7. Match meals to the day’s location and time; provide a nearby fallback.
8. Give every high-risk link a measurable Plan B trigger.
9. Track luggage separately whenever the travelers change hotels or enter a large attraction.

Separate an attraction’s admission ticket from shuttles, cableways, elevators, boats, performances, and optional experiences. For hotels, use the actual dates, occupancy, room count, total price, taxes, cancellation rule, luggage support, access, noise, and holiday surcharge. For group dining, distinguish per-person estimates from set menus and weight-priced dishes.

## Output and approval flow

1. First return the route skeleton, hard conditions, key reservations, and unresolved choices.
2. After the user confirms it, produce the requested guide using the relevant sections in the reference.
3. Put source links next to claims or in the source register.
4. End with a 7-day, 3-day, and same-day recheck list.
5. Generate travel-journal visuals only after the itinerary facts are stable, unless the user explicitly wants a concept mockup.

For visuals, use a two-stage workflow: create a no-text continuous illustrated map first, then add verified Chinese labels separately. Mark diagrammatic maps as non-navigational and not to scale. Never let an image model add unverified times, prices, stops, or addresses.

## Scope and permissions

Research, planning, and local artifact creation do not authorize purchases, reservations, cancellations, messages to providers, posts, or other external writes. Prepare booking links and checklists; ask for direct authorization before any external transaction or communication.
