# Travel Guide Structure and Decision Rules

Read this reference after intake for Standard and Execution planning.

## 1. Normalize the intake

Start with a short table:

| Category | Confirmed | Pending | Assumption/Conflict |
|---|---|---|---|
| Dates and travelers | ... | ... | ... |
| Fixed bookings | ... | ... | ... |
| Priorities | ... | ... | ... |
| Budget | ... | ... | ... |

Resolve only conflicts that materially change the route. State minor assumptions and proceed.

## 2. Route skeleton for confirmation

Before detailed research, show:

- one-sentence route concept;
- city/area sequence;
- each day’s theme, core stops, intensity, and lodging area;
- hard feasibility conditions;
- critical reservations;
- material tradeoffs between route options.

Do not bury the return deadline or a tight transfer.

## 3. Full guide sections

### A. One-page overview

- route arrow;
- daily theme table;
- booking priorities;
- hard conditions and deadlines;
- top risks and Plan B.

### B. Daily itinerary

For every day include:

- route, intensity, estimated walking, earliest start and latest finish;
- time, activity, exact entrance/address, door-to-door transport, cost, reservation, notes;
- meal and lodging;
- luggage location and handoff;
- risk, measurable trigger, and fallback.

Use 10–20% buffer. Do not fill every minute.

### C. Transport

Separate:

1. long-distance transport;
2. local public transport;
3. attraction shuttle/cableway/boat;
4. taxi, self-drive, or charter alternative.

Record full station names, departure/arrival points, operating window, last departure, duration, fare basis, luggage rules, and lookup date. Compare total group price when a taxi or charter may beat separate fares.

### D. Attractions and tickets

For each major attraction include:

- opening and closing information, closed days, reservation channel and ID requirements;
- base admission and optional shuttle/cableway/elevator/boat/show fees;
- recommended entrance, internal order, transport links, photo positions, meal/water points;
- must-keep nodes, first-to-drop nodes, and latest exit;
- terrain, stairs, accessibility, weather and equipment;
- official source and fallback.

### E. Food

Provide at least one route-compatible fallback per important meal. Record:

- branch and navigable address;
- hours, recent operating status, per-person range, signature dishes;
- spice level, allergens and unfamiliar local ingredients;
- reservation/group-buying availability and peak queue estimate;
- group ordering combination and total estimate;
- whether dishes are priced by portion or weight.

### F. Lodging

Compare actual dates, traveler count, rooms, occupancy, total price, taxes, breakfast, cancellation, holiday surcharge, access, noise, luggage, elevator, parking, laundry, and transfers.

Include a pre-booking question list and a stay card with address, phone, booking number, access, luggage handoff, transfer details, and emergency alternative.

### G. Budget

Keep per-person, whole-group, per-night, and room-night amounts distinct. Include:

- long-distance and local transport;
- accommodation;
- admission and internal transport;
- food;
- experiences;
- 10–15% contingency;
- excluded items.

Use ranges for dynamic prices and optionally show economy, comfort, and premium scenarios.

### H. Packing, tips, and emergencies

Group packing by documents/payment, electronics, clothing/weather, toiletries, medicines/safety, and destination-specific gear. Add:

- team roles for group travel;
- holiday crowd and price warnings;
- destination-specific health/weather/access notes;
- emergency, attraction, lodging, insurance, and traveler contacts;
- 7-day, 3-day, and same-day recheck list.

### I. Source register

| ID | Claim supported | Source title/organization | URL | Published/updated | Accessed | Grade |
|---|---|---|---|---|---|---|

Grade A for official/live sources, B for date-specific booking or map platforms, and C for reviews/social posts.

## 4. Plan B quality

A fallback is useful only when it has:

- a named risk;
- an observable trigger;
- the first adjustment;
- the second adjustment if needed;
- an owner when the group is large.

Examples of trigger types: queue over N minutes, delay over N minutes, ticket not confirmed by a date, weather warning above a level, or failure to reach an exit by a fixed time.

## 5. Travel-journal visual package

Recommended outputs:

1. whole-trip overview;
2. one internal map per major attraction;
3. packing checklist;
4. optional transfer, dining, or lodging contact card.

Use 3:4 for social posts, 9:16 for phone summaries, and A4 300 dpi for printing.

Preferred visual language:

- cream paper texture, watercolor/colored-pencil/ink;
- terracotta orange and lake teal route colors;
- one Chinese font;
- curved lines or dotted arrows;
- landmarks integrated into one continuous landscape.

Avoid fake Chinese, random English, emoji, dense legends, white presentation cards, and mechanically centered layouts.

Two-stage method:

1. Generate a no-text continuous bird’s-eye base map with accurate relative ordering and label space.
2. Add verified Chinese text, routes, times, transfer modes, and three concise reminders separately.

Every image must be checked against the guide for date, stop order, route direction, transport, price, and text legibility.

## 6. Final quality gate

Check:

- dates, nights, traveler count, rooms and totals agree;
- every fixed booking appears exactly once at the correct time;
- route geography and transfer timing are feasible;
- meals, rest, baggage and security are included;
- closing days, last departures and cancellation deadlines are visible;
- dynamic claims have lookup dates and sources;
- estimated data is not written as guaranteed;
- every major risk has a practical fallback;
- visuals contain no invented facts.

